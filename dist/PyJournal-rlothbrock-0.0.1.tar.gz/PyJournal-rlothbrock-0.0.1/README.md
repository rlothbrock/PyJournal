# PyJournal
Simple Python app for basic store management

This app contains basic tools for keep sales register and stock mantainment and update.
So far it uses sqlite for data storage, further versions may include MySql if demanded

The UI was made using PySide2

The app language is Spanish, but further versions may include other languages support

The final goal is to get a working app for handle small stores, and maybe including web capabilites for scaling 

Important: This is not a professional project, please not use it for commercial purposes. Any use is on your own risk

Any help to improve the project will be gladly accepted ;-)
